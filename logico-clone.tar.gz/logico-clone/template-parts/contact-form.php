<?php echo do_shortcode('[contact-form-7 id="1" title="Contact"]'); ?>

